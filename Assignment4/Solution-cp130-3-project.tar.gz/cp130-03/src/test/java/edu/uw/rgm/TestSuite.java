package edu.uw.rgm;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import test.BrokerTest;

@RunWith(Suite.class)
@Suite.SuiteClasses({BrokerTest.class})
public class TestSuite{
}
